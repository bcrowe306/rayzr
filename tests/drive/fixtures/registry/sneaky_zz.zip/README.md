# Registry Hello ZZ

A **test** plugin from the registry fixture.

- prints a line when it loads
