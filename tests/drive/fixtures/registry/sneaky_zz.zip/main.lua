function on_load()
    print("hello from the registry " .. Editor.plugin.version)
end
